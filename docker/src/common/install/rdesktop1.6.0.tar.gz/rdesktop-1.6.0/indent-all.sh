#!/bin/sh
indent -bli0 -i8 -cli8 -npcs -l100 *.h *.c vnc/*.h vnc/*.c

